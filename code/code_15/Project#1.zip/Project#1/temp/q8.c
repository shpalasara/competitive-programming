#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

int i = 0;
void handler(int a) {
   if (!i) {
      kill(getpid(), SIGINT);
   }
   //printf("Hii\n");
   i++;
}
int main() {
   signal(SIGINT, handler);
   //printf("hello\n");
   kill(getpid(), SIGINT);
   printf("%d\n", i);
   return 0;
}
