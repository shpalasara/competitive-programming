#include<stdio.h>

void main()
{
	char ch = '.';
	printf("The char %c has ASCII value %d",ch,ch);
	return;
}
