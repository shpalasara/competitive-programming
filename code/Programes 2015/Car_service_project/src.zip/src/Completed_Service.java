
public class Completed_Service extends Service_Booking{

	public Completed_Service(){
		
		//Payment=false;
	}
}
